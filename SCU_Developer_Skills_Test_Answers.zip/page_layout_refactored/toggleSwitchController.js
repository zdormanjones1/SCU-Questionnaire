var ToggleSwitchApp = angular.module('ToggleSwitchApp',[]);

populateOverdraftProtectionData = function($scope) {
	
	$scope.overdraftProtectionData = [
            { memberId: "0000123456", accountId: "S0009", ODT_Opt_In_Status_flag: true, Request_Method_flag: true },
            { memberId: "0001234567", accountId: "S0040", ODT_Opt_In_Status_flag: true, Request_Method_flag: false },
            { memberId: "0012345678", accountId: "S0040", ODT_Opt_In_Status_flag: false, Request_Method_flag: false }
        ];
		
	$scope.buttonClick = function() {
		alert($scope.overdraftProtectionData[1].ODT_Opt_In_Status_flag);
	};
};

ToggleSwitchApp.controller('ToggleSwitchController', populateOverdraftProtectionData);